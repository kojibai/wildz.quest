# Copy-Paste Integrations

These examples are intentionally small. They let a developer build with Receiz proof objects without inventing a parallel authority model.

The rule is the same in every example:

```txt
verify the sealed artifact -> reconstruct continuity -> project immediately -> admit verified truth -> sync verified additions after knownHead
```

The SDK is convenience, not authority. Proof objects, verified appends, ownership appends, settlement rows, and identity artifacts remain stronger truth.

## React Hook: `useReceizProofMemory`

```tsx
import { useEffect, useMemo, useState } from "react";
import {
  createReceizLocalStorageProofMemoryStorage,
  createReceizProofMemory,
  type ReceizProofMemory,
  type ReceizSdkObservation,
} from "@receiz/sdk";

export function useReceizProofMemory(ownerId: string) {
  const [memory, setMemory] = useState<ReceizProofMemory | null>(null);
  const [observations, setObservations] = useState<ReceizSdkObservation[]>([]);

  const storageKey = useMemo(() => `receiz:proof-memory:${ownerId}:v1`, [ownerId]);

  useEffect(() => {
    let active = true;

    void createReceizProofMemory({
      ownerId,
      storage: createReceizLocalStorageProofMemoryStorage(storageKey),
      onObservation: (observation) => {
        setObservations((current) => [...current.slice(-24), observation]);
      },
    }).then((opened) => {
      if (active) setMemory(opened);
    });

    return () => {
      active = false;
    };
  }, [ownerId, storageKey]);

  return {
    memory,
    observations,
    entries: memory?.entries() ?? [],
    knownHead: memory?.knownHead(100) ?? null,
  };
}
```

Use `entries` for immediate first paint. Use `knownHead` for append-only sync. Do not ask the server whether those entries are still true.

## Browser Complete Proof-Object Creation

```ts
import {
  createReceizClient,
} from "@receiz/sdk";

const receiz = createReceizClient();

export async function createProofObject(file: File) {
  return receiz.assets.createProofObject({
    assetType: "proof_object",
    payload: { mimeType: file.type, bytes: new Uint8Array(await file.arrayBuffer()) },
  }, { idempotencyKey: crypto.randomUUID(), filename: file.name });
}
```

The server resolves the real Receiz ID bound to the active session/token. Developers cannot submit an owner ID or construct a parallel continuity object. The method creates the native Receiz Record first, seals the source bytes at those same coordinates, then requires the native artifact to verify to the returned claim and verify path. Shape-valid manifests remain inspection-only.

## Next Route: Append Sync After Known Head

```ts
import { createReceizClient } from "@receiz/sdk";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const afterKaiUpulse = url.searchParams.get("afterKaiUpulse");
  const afterEntryId = url.searchParams.get("afterEntryId");

  const receiz = createReceizClient({
    accessToken: process.env.RECEIZ_CONNECT_ACCESS_TOKEN,
  });

  const ledger = await receiz.wallet.publicLedger({
    limit: 100,
    cursor: afterEntryId ?? undefined,
    since: afterKaiUpulse ?? undefined,
  });

  return Response.json({
    ok: true,
    additions: ledger.events,
  });
}
```

Use this as transport. Do not let this route replace local proof memory. It only returns possible additions.

## Webhook Receiver

```ts
import {
  assertReceizWebhookEvent,
  createReceizProofMemory,
  createReceizLocalStorageProofMemoryStorage,
  verifyReceizWebhookSignature,
} from "@receiz/sdk";

export async function receiveReceizWebhook(request: Request) {
  const body = await request.text();
  const signature = request.headers.get("x-receiz-signature") ?? "";
  const timestamp = request.headers.get("x-receiz-timestamp") ?? "";

  const ok = await verifyReceizWebhookSignature({
    secret: process.env.RECEIZ_WEBHOOK_SECRET!,
    timestamp,
    signature,
    body,
    toleranceSeconds: 300,
  });

  if (!ok) return new Response("invalid signature", { status: 401 });

  const event = assertReceizWebhookEvent(JSON.parse(body));
  const memory = await createReceizProofMemory({
    ownerId: "webhook-worker",
    storage: createReceizLocalStorageProofMemoryStorage("receiz:webhook-proof-memory:v1"),
  });

  memory.admitWebhookEvent(event);
  await memory.flush();

  return Response.json({
    ok: true,
    knownHead: memory.knownHead(100),
  });
}
```

Webhook signatures verify delivery. They do not become stronger than the proof bundle or append payload being admitted.

## Sports Card Renderer

This Sports card renderer keeps the proof object together while giving React developers a direct display component.

```tsx
import {
  assertReceizSportsCardManifest,
  projectReceizSportsCardManifest,
} from "@receiz/sdk";

export function SportsCardProof({ manifestJson }: { manifestJson: unknown }) {
  const manifest = assertReceizSportsCardManifest(manifestJson);
  const projection = projectReceizSportsCardManifest(manifest);

  return (
    <article>
      <img src={projection.mediaUrl ?? ""} alt={projection.title} />
      <h2>{projection.title}</h2>
      <p>{projection.scoreLabel}</p>
      <a href={projection.verifyUrl ?? manifest.links.proof}>Verify proof</a>
      <dl>
        {projection.rows.map((row) => (
          <div key={row.label}>
            <dt>{row.label}</dt>
            <dd>{row.href ? <a href={row.href}>{row.value}</a> : row.value}</dd>
          </div>
        ))}
      </dl>
    </article>
  );
}
```

Keep card identity, claim hash, ownership, value basis, append summary, and event proof summary together. They are one proof object projection.

## Receiz World Storefront Twin

Use the public World profile for first paint. Use delegated Twin methods only after the user authorizes your app through Connect.

```ts
import { createReceizClient } from "@receiz/sdk";

export async function loadPublicStorefront(username: string) {
  const receiz = createReceizClient();
  const world = await receiz.world.profile(username);
  if (!world.ok) throw new Error(world.error ?? "world_profile_failed");
  return world.world;
}

export async function runDelegatedTwin(accessToken: string) {
  const receiz = createReceizClient({ accessToken });
  const mandate = await receiz.twin.marketMandate();
  const intents = await receiz.twin.marketIntents();
  return { mandate: mandate.mandate, intents: intents.intents ?? [] };
}
```

The public surface is public proof projection. The delegated surface is scoped action permission. Do not use a Connect token as the identity proof root.

## Local CLI Proof

```bash
npx @receiz/sdk conformance
npx @receiz/sdk inspect ./receiz-asset-manifest.json
npx @receiz/sdk init ./receiz-integration
```

These commands prove the SDK can admit and project carried Receiz proof truth without network or database authority.
