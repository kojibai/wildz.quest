# Wallet Ledger Reads

```bash
npm install @receiz/sdk
```

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient();
let cursor: string | null | undefined;

do {
  const page = await receiz.wallet.publicLedger({ limit: 100, cursor });
  for (const event of page.events) {
    console.log(event.kind, event.amountPhiMicro, event.proofBundle);
  }
  cursor = page.nextCursor;
} while (cursor);
```

The wallet ledger is a settlement primitive projection. Display transfer, note mint, note claim, and proof bundle data as append-only ledger events. Keep already-read ledger events as verified history and append later pages or later additions beneath them.

Use pagination for large views. Do not flatten settlement into a generic balance-only view when the ledger event carries proof-native value, reserve, note, and transfer evidence.
