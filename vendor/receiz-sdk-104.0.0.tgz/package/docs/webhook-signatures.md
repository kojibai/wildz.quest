# Webhook Signatures

```bash
npm install @receiz/sdk
```

```ts
import { parseReceizWebhookRequest, routeReceizWebhookEvent } from "@receiz/sdk";

const parsed = await parseReceizWebhookRequest(request, {
  secret: process.env.RECEIZ_WEBHOOK_SECRET!,
  toleranceSeconds: 300,
});

await routeReceizWebhookEvent(parsed.event, {
  "payment.settled": async (event) => {
    await verifySettlementLedgerEvent(event.data);
  },
  "proof.appended": async (event) => {
    await verifyProofAppend(event.data);
  },
});
```

Webhook signature verification proves delivery authenticity for a webhook envelope. It does not replace artifact proof, verified appends, ownership appends, or settlement ledger truth.

Processing order:

1. Read the raw body.
2. Verify `x-receiz-signature` with `x-receiz-timestamp`.
3. Parse and validate `receiz.webhook_event.v1`.
4. Verify or fetch the underlying proof object, append, ownership state, or settlement ledger event before treating the event as product truth.

Endpoint management:

```ts
import { RECEIZ_WEBHOOK_EVENT_PRESETS, createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient({ accessToken: process.env.RECEIZ_ACCESS_TOKEN });

const created = await receiz.webhookEndpoints.create({
  label: "Production payments",
  url: "https://app.example.com/api/receiz/webhooks",
  eventTypes: RECEIZ_WEBHOOK_EVENT_PRESETS.payment,
  idempotencyKey: "webhook:production-payments:v1",
});

await storeSecretOnce(created.credentials.secret);
await receiz.webhookEndpoints.sendTest(created.endpoint.endpointId, { eventType: "payment.settled" });
```

Create and rotate return the plaintext endpoint secret once. List, update, test, and delete return configuration only.
