# Artifact Verification

```bash
npm install @receiz/sdk
```

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient();
const verified = await receiz.verification.verifyArtifact(file);

if (!verified.ok) {
  throw new Error(verified.errors.join(", "));
}

```

Receiz rule: verify integrity and continuity together, then project. The SDK makes the verification call and validates the manifest shape, but the proof object remains the sealed artifact/proof bundle, not the SDK response.

Native Profile Composer, Record, and Seal proof bundles remain the verification authority, including historically sealed proof objects. SDK proof-object creation resolves the authenticated account's real Receiz ID, creates its native Record projection before sealing, seals the source bytes at the same coordinates, and verifies the resulting native proof bundle. Generic byte sealing is not an SDK proof-object API.

Keep the original artifact bytes exactly as received. Store the manifest as a developer projection that points back to `proof.verifyUrl`, `proof.verifyPath`, and the deterministic proof identity.
