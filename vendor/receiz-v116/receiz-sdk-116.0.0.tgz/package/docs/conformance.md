# v109 conformance

Run the official local qualification:

```bash
pnpm receiz conformance
```

The SDK binary equivalent is `receiz conformance`; add `--human` for compact terminal output. JSON output uses `receiz.sdk.conformance_report.v1` and fixed checks for browser and React graphs, compiler Node execution, continuity, Record-before-Seal, webhook security, idempotency, proof-memory recovery, package compatibility, MCP parity, generated compilation, emulator determinism, and cold restoration.

Required failures exit nonzero. Default qualification makes zero network and database calls. Release qualification is evidence beneath sealed Receiz proof-object truth; it is not an artifact verdict.
