# App-State Public Projections

Receiz app-state projections let third-party apps publish public, durable, URL-addressed app state on Receiz rails. The SDK is convenience; the public proof rail is the durable projection/read surface. Connect/OIDC authorizes delegated server/agent writes. A merchant Receiz Key / Identity Seal authorizes merchant-owned public-store writes. Public reads recover the projection on cold start.

Use this for ecommerce storefronts, marketplaces, games, rewards, profiles, directories, blogs, access systems, and any app that needs public app state without adding a separate database.

## Publish After Admin Save

```ts
import {
  RECEIZ_PUBLIC_STORE_STATE_PROJECTION_SCHEMA,
  createReceizClient,
  createReceizPublicStoreStateRecord,
} from "@receiz/sdk";

const receiz = createReceizClient({
  baseUrl: "https://receiz.com",
  accessToken,
});

const storeProjection = createReceizPublicStoreStateRecord({
  sourceUrl: "bjklock.receiz.app",
  externalCreatorId: "bjklock.receiz.id",
  title: "BJ Klock storefront",
  data: {
    storeStateRecord,
  },
});

const published = await receiz.appState.publishRecord(storeProjection);
if (!published.ok) throw new Error(String(published.error ?? "app_state_publish_failed"));
```

`publishRecord()` wraps a single durable projection into the canonical feed envelope, derives the default object id from the URL, and normalizes a bare host such as `bjklock.receiz.app` to `https://bjklock.receiz.app`. Use `receiz.appState.publish(feed)` for batch writes. `receiz.publicProof.registryFeed(feed)` remains supported and aliases the same publish path.

For Commerce Cloud and tenant apps, the shortest path is the tenant publish helper:

```ts
await receiz.appState.publish({
  tenantHost: "bjklock.receiz.app",
  creatorReceizId: "bjklock.receiz.id",
  title: "BJ Klock storefront",
  state: { storeStateRecord },
  idempotencyKey: `storefront:${storeStateRecord.updatedKaiUpulse}`,
});
```

The SDK turns that into the canonical public app-state feed, derives the normalized URL, derives the object id, carries the `idempotency-key` header, and keeps the projection under the public proof registry rail.

## Publish With Identity Proof

For storefronts that carry the merchant's Receiz Key or verified Identity Seal, use the signed public-store rail. This does not require `RECEIZ_ACCESS_TOKEN`.

```ts
const signed = await receiz.publicStore.signPublish({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});

await receiz.publicStore.assertSignedPublishContract({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});

const published = await receiz.publicStore.publishSigned(signed);
console.log(published.knownHead.afterKaiUpulse, published.appendAnchorId);
```

Or use the one-call recipe:

```ts
const published = await receiz.publicStore.publishWithIdentityProof({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});
```

The law is direct: the proof object signs the publish feed, the public rail verifies that feed, and the rail returns the Kai/anchor append coordinate. Delegated access tokens remain useful for agents and server tools; they are not required for merchant-owned public-store sync.

For batch writes, build the canonical feed first:

```ts
import { createReceizAppStateFeed } from "@receiz/sdk";

const feed = createReceizAppStateFeed([storeProjection], {
  schema: "receiz.app.public_store_state_registry_feed.v1",
  externalCreatorId: "bjklock.receiz.id",
});

await receiz.appState.publish(feed);
```

The same factories are available from the client namespace:

```ts
const objectId = receiz.appState.objectIdFromUrl("https://bjklock.receiz.app");
const namespace = receiz.appState.namespaceFromUrl("https://bjklock.receiz.app");
const url = receiz.appState.urlFromHost("bjklock.receiz.app");
const record = receiz.appState.createPublicStoreRecord({
  sourceUrl: url,
  data: { storeStateRecord },
});
```

## Recover On Cold Start

```ts
import {
  RECEIZ_PUBLIC_STORE_STATE_PROJECTION_SCHEMA,
  createReceizClient,
} from "@receiz/sdk";

const receiz = createReceizClient();
const restored = await receiz.appState.restoreByHost<{
  storeStateRecord: StoreStateRecord;
}>("bjklock.receiz.app", {
  schema: RECEIZ_PUBLIC_STORE_STATE_PROJECTION_SCHEMA,
  state: "published",
  requiredDataKey: "storeStateRecord",
});

if (!restored.ok || !restored.data) {
  throw new Error("storefront_state_not_found");
}

const storeStateRecord = restored.data.storeStateRecord;
```

`https://bjklock.receiz.app` and `https://bjklock.receiz.app/` resolve to the same public projection. Subdomains and custom domains work through the same normalized URL key.

Use `byUrl()` when the app already has a full URL. Use `byHost()` when the current request gives you only the tenant host or custom domain.
Use `restoreByUrl()`, `restoreByHost()`, or `restoreById()` when the app should receive the typed projection data directly for first paint.
Use `resolve()` when your app accepts host, URL, id, namespace, or creator input and wants one typed API:

```ts
const restored = await receiz.appState.resolve<{
  storeStateRecord: StoreStateRecord;
}>({
  host: "bjklock.receiz.app",
  schema: RECEIZ_PUBLIC_STORE_STATE_PROJECTION_SCHEMA,
  state: "published",
  requiredDataKey: "storeStateRecord",
});
```

When your app already has a public projection response, unwrap it without another network call:

```ts
import { extractReceizAppStateData } from "@receiz/sdk";

const data = extractReceizAppStateData<{
  storeStateRecord: StoreStateRecord;
}>(restored, {
  schema: RECEIZ_PUBLIC_STORE_STATE_PROJECTION_SCHEMA,
  requiredDataKey: "storeStateRecord",
});
```

## Namespace And Creator Reads

```ts
const byCreator = await receiz.appState.byCreator("bjklock.receiz.id");
const byNamespace = await receiz.appState.byNamespace("bjklock.receiz.app");
const byId = await receiz.appState.byId("store_state_id:bjklock.receiz.app");
```

Use namespace reads for tenant directories, app categories, marketplace collections, and custom-domain indexes. Use by-id reads when the app already has a durable projection object id.

## Payload Limits

The app-state feed endpoint accepts JSON bodies up to 2 MiB and up to 50 records per feed. Oversized requests return:

```json
{ "ok": false, "error": "payload_too_large" }
```

Invalid feed shape returns:

```json
{ "ok": false, "error": "invalid_schema" }
```

Missing, invalid, or insufficient delegated bearer tokens return:

```json
{ "ok": false, "error": "unauthorized" }
```

## Security Model

Reads are public because the projection is public app state.

Writes require a Receiz Connect/OIDC bearer token with `receiz:record`. A URL projection can be created on an unowned public proof row or updated by the same delegated Receiz user that published it. A different user cannot overwrite an already-owned app-state projection for the same normalized URL.

This rail does not replace sealed artifacts, identity proofs, ownership appends, settlement records, or local proof memory. It indexes public app state so apps can recover first paint from Receiz truth after cold starts.
