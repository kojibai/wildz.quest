# Receiz App Contract Compiler

Define one typed `receiz.app.contract.v1` contract with `defineReceizApp`, then
compile it with `compileReceizAppContract`. The deterministic plan contains
rails, OIDC scopes, environment names, public/delegated operations, authority
boundaries, framework requirements, generated modules, findings, verification
commands, rollback guidance, and machine-readable dispositions.

Use `inspectReceizProject`, `planReceizIntegration`,
`checkReceizIntegration`, `planReceizUpgrade`, and
`explainReceizIntegrationFinding` for repository workflows. Inspection is not
artifact verification. Proof creation remains authenticated native Record before
Seal, and `verification.verifyArtifact` remains the integrity/owner/namespace/
continuity verdict.

Findings are `satisfied`, `safe_automatic_change`, `user_decision_required`,
`manual_implementation_required`, `blocked_missing_capability_or_authority`, or
`unsafe_or_incompatible`.
