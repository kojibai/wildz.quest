# Generated Files And Upgrades

`createReceizIntegrationPreview` returns every proposed change and a SHA-256
digest without writing. `applyReceizIntegrationPreview` requires that exact
digest, rechecks repository state, rejects traversal/symlink escape/stale
previews, and writes atomically.

Automatic changes are limited to Receiz-generated files, approved
`package.json` fields, and explicit generated blocks. Unmarked source is manual
work. Repeating an applied plan yields zero changes.

Upgrade planning compares the contract, repository evidence, installed
SDK/MCP/AI-skills versions, and target SDK. It preserves historical proof
objects, never rewrites witnessed history, appends missing truth, and rebuilds
incorrect projections from stronger verified truth.
