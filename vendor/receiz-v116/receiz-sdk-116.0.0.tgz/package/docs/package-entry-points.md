# Package entry points

Receiz v109 separates runtime, UI, compiler, and testing code without changing proof authority.

```ts
import { createReceizClient } from "@receiz/sdk";
import { ReceizProvider, useReceiz } from "@receiz/sdk/react";
import { defineReceizApp, inspectReceizProject } from "@receiz/sdk/compiler";
import { createReceizEmulator, runReceizConformance } from "@receiz/sdk/testing";
```

`@receiz/sdk` and `@receiz/sdk/react` contain no transitive `node:*` import. `@receiz/sdk/compiler` is Node-only. `@receiz/sdk/testing` is browser-safe, in-memory, and sandbox-only.

No version-specific historical developer entry point is exported or packed.
Current profile, artifact, ownership, offline proof-memory, and media rails are
available only through the maintained unversioned package surfaces above.

Move legacy compiler imports from the root to `@receiz/sdk/compiler`. Runtime imports remain at the root. Mixed imports must be split. `receiz app upgrade` and `receiz_app_upgrade` report exact safe migrations; ambiguous namespace, default, and dynamic imports require review.

No entry point, compiler result, or testing result outranks a sealed Receiz proof object.

The root runtime entry point is the sole public artifact-custody API:

```ts
const sealed = await receiz.assets.createProofObject(input, options);
await receiz.artifacts.download(sealed);
const opened = await receiz.artifacts.verifyAndOpen(file);
consume(opened.verifiedPayload.bytes);
```

`ReceizSealedArtifact` is issued only by the SDK runtime after native Record -> Seal and complete verification succeed. A plain `Blob`, type cast, copied object, inner payload, or verified legacy read cannot be relabeled as a current downloadable artifact. Internal issuers are not package entry points.

In the workflow above, `file` is the complete sealed artifact selected for verification, never the source payload.
