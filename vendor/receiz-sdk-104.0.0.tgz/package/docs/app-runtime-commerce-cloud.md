# Receiz App Runtime And Commerce Cloud Rails

`@receiz/sdk` exposes typed rails for apps that want Receiz identity, public app-state, commerce, media, domains, events, proof search, jobs, permissions, audit, risk, compliance, portability, notifications, release pinning, offline proof queues, and diagnostics without stitching a separate app backend together first.

The SDK is convenience. It does not become proof authority. Proof objects, verified local truth, app-state projections, Connect delegated routes, wallet settlement, identity artifacts, and durable append rails remain the source of truth.

## Self-Debug First

```ts
import { RECEIZ_OIDC_SCOPES_BY_RAIL, createReceizClient, receizOidcScopesForRails } from "@receiz/sdk";

const receiz = createReceizClient({ accessToken });

const doctor = await receiz.doctor({
  tenantHost: "bjklock.receiz.app",
  callbackUrl: "https://bjklock.receiz.app/api/auth/receiz/callback",
  scopes: receizOidcScopesForRails("identity", "customers", "merchants", "publicStore", "commerce"),
});

if (!doctor.ok) {
  console.table(doctor.fixes);
}

const caps = await receiz.capabilities({ tenantHost: "bjklock.receiz.app" });
if (!caps.capabilities.customers.available || !caps.capabilities.merchants.available || !caps.capabilities.commerce.available) {
  // Hide checkout setup or show the exact Connect fix.
}

console.log(RECEIZ_OIDC_SCOPES_BY_RAIL.publicStore);
```

## Publish And Resolve Tenant State

```ts
await receiz.publicStore.publish({
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  title: "BJ Klock storefront",
  state: storeStateRecord,
  idempotencyKey: `storefront:${storeStateRecord.updatedKaiUpulse}`,
});

const restored = await createReceizClient().publicStore.resolve<StoreStateRecord>({
  host: "bjklock.receiz.app",
});

if (restored.ok && restored.storeStateRecord) {
  renderStorefront(restored.storeStateRecord);
}
```

For merchant-owned publish without an environment token, use the Identity Seal path:

```ts
const append = await createReceizClient().publicStore.publishWithIdentityProof({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});

await localProofMemory.admit({
  kaiUpulse: append.knownHead.afterKaiUpulse,
  proof: append.appendProof,
});
```

`publishWithIdentityProof()` signs the canonical public-store feed with the merchant's Receiz Key, the public proof rail verifies that signed feed, and the SDK returns the append coordinate. Use delegated tokens for server agents and Connect tasks; do not use them as merchant proof authority.

`receiz.appState.publish()` and `receiz.appState.resolve()` remain available for custom app projections. `receiz.publicStore.*` is the first-party commerce-store namespace so every storefront uses the same public projection envelope.

## Local-First Dogfood Recipes

```ts
const runtime = await receiz.runtime.localFirst({
  ownerId: "bjklock.receiz.id",
  storage: receiz.proofMemory.createLocalStorage("receiz:profile:bjklock"),
  seed: [identityRecord, currentProfileManifest],
  sync: (knownHead) => fetchVerifiedAdditionsAfter(knownHead),
  limit: 100,
});

const profile = await receiz.profile.resolveLocalFirst({
  memory: runtime.memory,
  local: admittedProfileTruth,
  sync: (knownHead) => fetchVerifiedProfileAdditions(knownHead),
});

const wallet = await receiz.wallet.resolveLedger({
  memory: runtime.memory,
  local: admittedWalletLedger,
  sync: (knownHead) => fetchVerifiedLedgerAdditions(knownHead),
});

const cardMemory = await receiz.sports.resolveCardMemory({
  memory: runtime.memory,
  local: admittedSportsCardMemory,
  sync: (knownHead) => fetchVerifiedSportsAdditions(knownHead),
});

const pitchDay = await receiz.sports.resolvePitchDayProof({
  local: admittedPitchDayProof,
});
```

These recipes are for dogfooding `@receiz/sdk` inside Receiz later without making the SDK a truth authority. If `local` exists, the recipe returns it immediately and starts append sync after the known head. `remote` is only used when local truth is absent.

## One-Click Checkout

```ts
const checkout = await receiz.commerce.oneClickCheckout({
  tenantHost: "bjklock.receiz.app",
  orderId: "order_123",
  amountUsd: "42.00",
  walletFirst: true,
  cardFallback: true,
  idempotencyKey: "order_123",
  cart,
});

if (checkout.checkoutSession?.clientSecret) {
  openEmbeddedCardDeltaPanel(checkout.checkoutSession.clientSecret);
}
```

Wallet-first checkout reads the delegated wallet summary, computes the card delta, and creates an embedded Connect checkout session only when a card delta remains. Settlement truth still belongs to the Connect/payment and wallet rails returned by the backend.

## Enterprise Commerce

```ts
await receiz.customers.session({
  tenantHost: "bjklock.receiz.app",
  customerReceizId: "customer.receiz.id",
  scopes: ["orders", "rewards", "assets"],
}, { idempotencyKey: "customer-session:v1" });

const tenantSession = await receiz.customers.bootstrapSession({
  tenantHost: "bjklock.receiz.app",
  customerReceizId: "customer.receiz.id",
  scopes: ["orders", "rewards", "assets"],
}, { idempotencyKey: "customer-session:v1" });

renderCustomerAccount({
  session: tenantSession.session,
  wallet: tenantSession.wallet,
  customer: tenantSession.customer,
  permissions: tenantSession.permissions,
});

const hostedIdentity = receiz.identity.ensureTenantSession({
  tenantHost: "bjklock.receiz.app",
  returnTo: "https://bjklock.receiz.app/account",
  fallback: "artifact_upload",
});

await receiz.merchants.onboard({
  tenantHost: "bjklock.receiz.app",
  receizId: "bjklock.receiz.id",
  displayName: "BJ Klock",
  defaultStore: { title: "BJ Klock Store" },
}, { idempotencyKey: "merchant:bjklock:v1" });

await receiz.commerce.inventory.reserve({
  tenantHost: "bjklock.receiz.app",
  sku: "hat-black",
  quantity: 2,
}, { idempotencyKey: "inventory:hat-black:cart-123" });

await receiz.commerce.fulfillment.update({
  tenantHost: "bjklock.receiz.app",
  orderId: "order_123",
  status: "shipped",
}, { idempotencyKey: "fulfillment:order_123:shipped" });
```

Additional commerce rails include refunds, subscriptions, shipping quotes, tax quotes, discounts, gift cards, access passes, inventory adjustment, and merchant payouts. Every write accepts an idempotency key so retries append once.

## Media, Domains, Events, Search, And Jobs

```ts
const logo = await receiz.media.upload(file, {
  tenantHost: "bjklock.receiz.app",
  purpose: "store.logo",
  filename: "logo.png",
  idempotencyKey: "store-logo:v1",
});

const tenantUrl = receiz.domains.tenantUrl("bjklock.receiz.app");
const namespace = receiz.domains.namespace(tenantUrl);

await receiz.events.subscribe({
  tenantHost: "bjklock.receiz.app",
  types: ["order.created", "payment.settled", "reward.claimed"],
  webhookUrl: "https://bjklock.receiz.app/api/receiz/webhooks",
  idempotencyKey: "events:v1",
});

const orders = await receiz.proof.query({
  namespace,
  tenantHost: "bjklock.receiz.app",
  type: "commerce.order",
});

await receiz.jobs.enqueue({
  tenantHost: "bjklock.receiz.app",
  kind: "media.process",
  payload: { mediaId: logo.media?.id },
  idempotencyKey: "media.process:logo:v1",
});

await receiz.media.transform({
  tenantHost: "bjklock.receiz.app",
  mediaId: String(logo.media?.id),
  resize: { width: 1200 },
  optimize: { format: "webp" },
  blurPlaceholder: true,
  altText: "Store logo",
}, { idempotencyKey: "media.transform:logo:v1" });

await receiz.events.replay({
  tenantHost: "bjklock.receiz.app",
  types: ["order.created", "payment.settled"],
  since: "2026-06-01T00:00:00.000Z",
});
```

## Permissions, Audit, Risk, Compliance, And Portability

```ts
await receiz.permissions.grant({
  tenantHost: "bjklock.receiz.app",
  actorReceizId: "staff.receiz.id",
  role: "fulfillment",
}, { idempotencyKey: "grant:staff:fulfillment" });

await receiz.audit.append({
  tenantHost: "bjklock.receiz.app",
  action: "product.updated",
  actorReceizId: "bjklock.receiz.id",
}, { idempotencyKey: "audit:product:update:123" });

const risk = await receiz.risk.scorePayment({
  tenantHost: "bjklock.receiz.app",
  orderId: "order_123",
  amountUsd: "42.00",
});

const orders = await receiz.compliance.exportOrders({
  tenantHost: "bjklock.receiz.app",
  from: "2026-06-01",
  to: "2026-06-30",
});

const portableStore = await receiz.portability.exportStore({
  tenantHost: "bjklock.receiz.app",
});
```

Audit, risk, compliance, and portability are projections over proof-native activity. They help applications operate; they do not outrank the proof objects, wallet settlement, or verified appends they project.

## Offline Queue And Release Pinning

```ts
const storage = receiz.offline.createLocalStorage("receiz:queue:bjklock");
const queue = await receiz.offline.createQueue({
  ownerId: "bjklock.receiz.id",
  storage,
});

queue.enqueue({
  id: "store-state:offline-1",
  kind: "app_state.publish",
  payload: {
    tenantHost: "bjklock.receiz.app",
    title: "Offline storefront append",
    state: { storeStateRecord },
  },
  idempotencyKey: "store-state:offline-1",
});
await queue.flush();

await queue.replay(receiz);

await receiz.releases.pin({
  tenantHost: "bjklock.receiz.app",
  rails: { appState: "v1", commerce: "v1", media: "v1" },
}, { idempotencyKey: "rails:pin:v1" });
```

## Deterministic Sandbox

```ts
const store = receiz.sandbox.seedStore({ tenantHost: "demo.receiz.app", products: 3 });
const wallet = receiz.sandbox.wallet({ balanceUsdCents: "5000" });
const checkout = receiz.sandbox.checkout({ amountUsd: "19.95", outcome: "success" });
```

The sandbox is local and deterministic. Use it for tests, demos, and AI-generated apps before wiring delegated Connect access.

## CLI

```bash
receiz doctor --tenant-host bjklock.receiz.app --access-token "$RECEIZ_ACCESS_TOKEN"
receiz dev
receiz deploy-check --tenant-host bjklock.receiz.app
receiz seed-store --tenant-host demo.receiz.app --products 3
receiz simulate-checkout --amount-usd 19.95
```

These commands do not make the CLI a truth authority. They are local developer diagnostics and sandbox helpers.
