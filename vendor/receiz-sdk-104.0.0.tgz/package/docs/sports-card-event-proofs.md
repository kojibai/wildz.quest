# Sports Card And Event Proof Integration

```bash
npm install @receiz/sdk
```

```ts
import { assertReceizSportsCardManifest, createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient();
const conformance = await receiz.sports.conformance();
const manifest = assertReceizSportsCardManifest(await sportsCardManifestResponse.json());
const eventProofUrl = receiz.sports.eventProofUrl("event_proof_123");

console.log(conformance.reportHash, manifest.collectibleId, eventProofUrl);
```

Sports cards are proof objects. The manifest carries card identity, ownership/custody, value basis, append summary, event proof summary, and links. The SDK validates the projection and gives you typed calls, but verified appends and event proofs remain the source of truth.

For lazy integrations:

1. Render `card`, `ownership`, and `valueBasis` from the manifest.
2. Use `appendSummary` and `eventProofSummary` as quick visible proof memory.
3. Link each event proof through `receiz.sports.eventProofUrl(eventProofId)`.
4. Poll or refresh only for verified additions, not to re-prove admitted card history.
