# Signed Public Store Publish

`@receiz/sdk@99.0.0` exposes a merchant proof-owned public-store publish path.

This is the correct path when a merchant has a Receiz Key / Identity Seal and wants to publish durable storefront state without a server bearer token.

## Law

```txt
Identity Seal / Receiz Key signs public-store feed
-> Receiz public proof rail verifies the signed envelope
-> rail appends the public projection
-> SDK returns Kai/anchor append coordinate
-> app stores the known head and resolves latest public truth
```

`RECEIZ_ACCESS_TOKEN` is not required for this lane. Delegated tokens remain valid for agent/server tasks, but they are not merchant proof authority.

## One-Shot Publish

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient({ baseUrl: "https://receiz.com" });

const result = await receiz.publicStore.publishWithIdentityProof({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});

console.log(result.kaiPulse);
console.log(result.appendAnchorId);
console.log(result.knownHead.afterKaiUpulse);
```

## Split Publish

Use this when an app needs to inspect or persist the signed envelope before posting it.

```ts
const signed = await receiz.publicStore.signPublish({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});

const result = await receiz.publicStore.publishSigned(signed);
```

## Recovery

```ts
const state = await receiz.publicStore.restoreLatest({
  host: "bjklock.receiz.app",
  requiredSchema: "receiz.app.store_state.v1",
});

if (state.ok && state.storeStateRecord) {
  renderStorefront(state.storeStateRecord);
}
```

## Conformance

```ts
await receiz.publicStore.assertSignedPublishContract({
  keyFile,
  tenantHost: "bjklock.receiz.app",
  merchantReceizId: "bjklock.receiz.id",
  storeStateRecord,
});
```

## Result Shape

```ts
type ReceizPublicStoreAppendResult = {
  ok: true;
  storeStateRecordId: string;
  tenantHost: string;
  kaiPulse: string;
  appendAnchorId: string;
  appendProof: JsonObject;
  knownHead: {
    afterKaiUpulse: string;
    appendAnchorId: string;
  };
};
```

## Boundary

- Use `publishWithIdentityProof` for merchant-owned public store state.
- Use delegated tokens for trusted agent/server tasks.
- Use `restoreLatest` for cold-start public storefront first paint.
- Do not add a new database, token, signer, or server authority when the merchant proof object already carries the publish boundary.
