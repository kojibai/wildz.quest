# Proof Memory And Projections

The Receiz SDK gives developer apps the same default shape Receiz uses internally:

```txt
verify proof object -> project immediately -> admit into durable proof memory -> append verified additions
```

The SDK is convenience. It is not authority. The authority remains the sealed artifact, proof bundle, verified append, ownership append, and settlement ledger record.

Kai Klok is the proof object state machine. `kaiPulseEternal` is the pulse unit carried by that state machine. A complete Receiz proof object carries Kai; without its Kai coordinate it is not complete Receiz proof truth.

## Install

```bash
npm install @receiz/sdk
```

## Project A Proof Object

```ts
import { projectReceizAssetManifest } from "@receiz/sdk";

const projection = projectReceizAssetManifest(manifest);

render({
  title: projection.title,
  subtitle: projection.subtitle,
  mediaUrl: projection.mediaUrl,
  verifyUrl: projection.verifyUrl,
  rows: projection.rows,
});
```

Projection is deterministic display preparation. It does not verify the artifact by itself. Verify first when the manifest comes from an untrusted transport.

## Project A Sports Card

```ts
import { projectReceizSportsCardManifest } from "@receiz/sdk";

const projection = projectReceizSportsCardManifest(cardManifest);

renderSportsCard({
  player: projection.title,
  value: projection.valueLabel,
  score: projection.scoreLabel,
  proofRows: projection.rows,
});
```

The projection keeps card identity, claim hash, ownership, value basis, append summary, and event proof summary together. Do not split those into unrelated app models.

## Admit Once, Append Forever

```ts
import {
  createReceizLocalStorageProofMemoryStorage,
  createReceizProofMemory,
} from "@receiz/sdk";

const memory = await createReceizProofMemory({
  ownerId: currentUserId,
  storage: createReceizLocalStorageProofMemoryStorage(`receiz:${currentUserId}:proof-memory`),
});

memory.admitWebhookEvent(webhookEvent);

await memory.flush();
```

The storage adapter only persists already-admitted truth. It does not verify, mint, rewrite, or outrank the proof object. On next open, the same call reopens the stored register and you render it immediately:

```ts
const memory = await createReceizProofMemory({
  ownerId: currentUserId,
  storage: createReceizLocalStorageProofMemoryStorage(`receiz:${currentUserId}:proof-memory`),
});

const knownTruth = memory.entries();
```

Then ask Receiz for verified additions after your known head. Do not ask whether known proof is still true.

```ts
const after = memory.knownHead(50);

await fetch(`/api/receiz/additions?afterKaiUpulse=${after.afterKaiUpulse ?? ""}`);
```

## Receiz Account Restore Boundary

Receiz Key, Identity Record, and Identity Seal restore use the same law inside Receiz itself. Current restore artifacts carry `receiz.account.state.v3`, which includes profile/account state, action ledger, calendar events, wallet settlement rows and notes, Sports vault cards, pack purchases, card appends, event proofs, entries, competitions, and tournament state.

That private identity artifact is stronger than a later API response. Restore projects the carried account proof memory first; server/database sync may only mirror missing rows or append verified additions the artifact does not possess. It must not rediscover old truth before use.

Developer apps should apply the same pattern with SDK proof memory: store admitted proof objects locally, paint from that known prefix immediately, then request additions after the known head. The SDK does not mint private Receiz login images or keys; it gives external apps the same admit-once, append-forever operating model.

## Duplicate Transport Is Safe

If the same verified register entry arrives again through another transport, the register keeps the first admitted payload and only fills missing fields. This prevents a weaker partial response from dropping known truth. Asset and Sports manifests are projections only and cannot enter proof memory; SDK asset admission requires the complete sealed proof object.

```ts
memory.append(fullVerifiedRegisterEntry);
memory.append(repeatedVerifiedRegisterEntry);

const retained = memory.snapshot().entries[0];
```

This is intentional. Receiz proof memory is not `newest response wins`.

## Storage Adapters

Browser apps can use `createReceizLocalStorageProofMemoryStorage()`. Server-rendered or test environments can provide the same small interface:

```ts
import { createReceizProofMemory, type ReceizProofMemoryStorage } from "@receiz/sdk";

const storage: ReceizProofMemoryStorage = {
  read: async () => durableStore.get("proof-memory"),
  write: async (snapshot) => durableStore.set("proof-memory", JSON.stringify(snapshot)),
};

const memory = await createReceizProofMemory({ storage });
```

For tests and demos, use `createReceizInMemoryProofMemoryStorage()`.

## Runtime Schema Exports

```ts
import { RECEIZ_SCHEMAS } from "@receiz/sdk";

const assetManifestSchema = RECEIZ_SCHEMAS.assetManifest;
const sportsCardSchema = RECEIZ_SCHEMAS.sportsCardManifest;
const webhookEventSchema = RECEIZ_SCHEMAS.webhookEvent;
```

The schemas are packaged for docs, validation UIs, generated forms, test fixtures, and developer tooling. Runtime validators remain available as:

```ts
import {
  assertReceizAssetManifest,
  assertReceizSportsCardManifest,
  assertReceizWebhookEvent,
} from "@receiz/sdk";
```

## Production Rule

Use this order in every integration:

1. Verify stronger proof truth when bytes come from an untrusted transport.
2. Validate the manifest or event shape.
3. Project display-ready rows from the verified object.
4. Admit the object into proof memory.
5. Persist the proof memory snapshot.
6. Resume from the known Kai/proof head.
7. Append later verified additions without rediscovering known truth.

This gives users truthful first paint and gives developers a simple integration that stays aligned with Receiz primitives.
