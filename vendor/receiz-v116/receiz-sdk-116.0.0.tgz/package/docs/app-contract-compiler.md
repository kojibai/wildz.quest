# Receiz App Contract Compiler

Define one typed `receiz.app.contract.v1` contract with `defineReceizApp`, then
compile it with `compileReceizAppContract`. The deterministic plan contains
rails, OIDC scopes, environment names, public/delegated operations, authority
boundaries, framework requirements, generated modules, findings, verification
commands, rollback guidance, and machine-readable dispositions.

Use `inspectReceizProject`, `planReceizIntegration`,
`checkReceizIntegration`, `planReceizUpgrade`, and
`explainReceizIntegrationFinding` for repository workflows. Inspection is not
artifact verification. Proof creation remains authenticated native Record before
Seal, and `verification.verifyArtifact` remains the integrity/owner/namespace/
continuity verdict.

With `targetSdkVersion: "109.0.0"`, the compiler emits the current native
developer outcomes declared by the contract's features:

- identity adds `profile.update`, the neutral admitted-account same-UID profile
  operation;
- proof adds `assets.createProofObject`, `artifacts.verifyAndOpen`,
  `artifacts.download`, and `ownership.claimBearerAsset`;
- ownership consumes the complete sealed artifact before the authenticated
  owner append.

The v109 plan does not advertise retired key/head/receipt transports and cannot
target an obsolete version-specific developer SDK.

Findings are `satisfied`, `safe_automatic_change`, `user_decision_required`,
`manual_implementation_required`, `blocked_missing_capability_or_authority`, or
`unsafe_or_incompatible`.
