# App Registration And Token Lifecycle

```bash
npm install @receiz/sdk
```

```ts
import { createReceizClient } from "@receiz/sdk";

const receiz = createReceizClient();
const authorizeUrl = receiz.identity.authorizeUrl({
  clientId: process.env.RECEIZ_CLIENT_ID!,
  redirectUri: "https://app.example.com/auth/receiz/callback",
  codeChallenge,
  scope: ["openid", "profile", "receiz:verify", "receiz:wallet.transfer", "receiz:twin.read"],
  state,
});
```

Receiz Connect is delegated API access. It uses standard OIDC mechanics for app onboarding and token lifecycle, but it is not the identity proof root. Receiz ID, Receiz Key, Identity Record, and Identity Seal remain the identity primitives; Connect tokens authorize scoped API calls after that proof boundary.

Lifecycle:

1. Register the app and exact redirect URI.
2. Start Authorization Code + PKCE with the scopes your app needs.
3. Exchange the authorization code server-side.
4. Store refresh tokens server-side only.
5. Use access tokens for `receiz.connect.*` calls.
6. Revoke tokens when the user disconnects your app.

Use `sub` from OIDC as the stable external user key. Do not key your user model by mutable email.

Public Receiz World reads do not require OIDC. Delegated owner actions, including Twin market mandates, Twin intents, Twin mind import/export, wallet transfers, records, seals, verification, payments, and note actions, require a registered OIDC client and a user-granted access token. Business/developer accounts are the correct place to create and manage those clients, redirect URIs, scopes, and token lifecycle.
