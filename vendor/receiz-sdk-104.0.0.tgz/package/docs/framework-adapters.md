# Framework Adapter Architecture

The compiler core is framework-neutral. `nextjs-app-router` is the first complete
adapter and generates separate server client, browser client, project adapter,
environment validation, OIDC callback, verification route, public-store adapter,
proof-memory interface, webhook receiver, fixtures, and conformance test.

Adapters implement `ReceizFrameworkAdapter` and return sorted
`ReceizGeneratedFile` values. A third-party adapter may add a new framework
implementation without changing `receiz.app.contract.v1`; it must retain the
artifact-first authority boundary, server/browser credential separation,
idempotency, and native verification/continuity rails.
